package com.tfar.notenoughrtgs.config;

public class Config {
}
