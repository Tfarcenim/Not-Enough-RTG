package com.tfar.notenoughrtgs.util;

public interface IHasModel {
    public void registerModels();
}
